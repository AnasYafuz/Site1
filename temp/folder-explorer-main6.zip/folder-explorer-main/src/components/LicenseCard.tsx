import { useState } from 'react';
import { Key, User, Clock, Cpu, Calendar, Edit, Trash2, RotateCcw, Copy, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { License } from '@/lib/types';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface LicenseCardProps {
  license: License;
  isAdmin: boolean;
  onEdit?: (license: License) => void;
  onDelete?: (licenseId: string) => void;
  onResetSerial?: (licenseId: string) => void;
}

export function LicenseCard({ license, isAdmin, onEdit, onDelete, onResetSerial }: LicenseCardProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const isExpired = new Date(license.expires_at) < new Date();
  const isActive = license.is_active && !isExpired;

  const copyLicenseKey = async () => {
    await navigator.clipboard.writeText(license.license_key);
    setCopied(true);
    toast({
      title: 'تم النسخ',
      description: 'تم نسخ مفتاح الترخيص',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const gradientClass = license.tool_type === 'AMPro Tool' 
    ? 'from-primary via-purple-500 to-accent' 
    : 'from-orange-500 to-amber-600';

  return (
    <Card className={cn(
      'group relative overflow-hidden border-0 bg-slate-800/50 backdrop-blur-xl transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl',
      isActive ? 'hover:shadow-primary/20' : 'opacity-70 hover:shadow-red-500/20'
    )}>
      <div className={cn('absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-500', gradientClass)} />
      
      <CardContent className="p-6 relative">
        <div className="flex flex-col gap-4">
          {/* Header */}
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className={cn(
                'relative w-12 h-12 rounded-xl bg-gradient-to-br p-0.5 shadow-lg group-hover:scale-110 transition-transform duration-300',
                gradientClass
              )}>
                <div className="w-full h-full rounded-xl bg-slate-900 flex items-center justify-center">
                  <Key className="w-6 h-6 text-white" />
                </div>
                {isActive && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                    <Sparkles className="w-2.5 h-2.5 text-white" />
                  </div>
                )}
              </div>
              <div>
                <h3 className="font-bold text-white group-hover:text-primary transition-colors">{license.customer_name}</h3>
                <p className="text-xs text-slate-400">{license.tool_type}</p>
              </div>
            </div>
            <Badge 
              className={cn(
                'border-0 shadow-lg',
                isActive 
                  ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white' 
                  : 'bg-gradient-to-r from-red-500 to-rose-600 text-white'
              )}
            >
              {isActive ? 'نشط' : 'منتهي'}
            </Badge>
          </div>

          {/* License Key */}
          <div className="flex items-center gap-2 p-3 bg-slate-900/50 rounded-xl border border-slate-700/50">
            <code className="flex-1 text-sm font-mono text-slate-300" dir="ltr">
              {license.license_key}
            </code>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-700"
              onClick={copyLicenseKey}
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Clock className="w-4 h-4 text-primary" />
              <span>{license.duration_days} يوم</span>
            </div>
            <div className="flex items-center gap-2 text-slate-400">
              <Calendar className="w-4 h-4 text-accent" />
              <span>{format(new Date(license.expires_at), 'dd MMM yyyy', { locale: ar })}</span>
            </div>
            {license.device_serial && (
              <div className="flex items-center gap-2 text-slate-400 col-span-2">
                <Cpu className="w-4 h-4 text-purple-400" />
                <span className="truncate" dir="ltr">{license.device_serial}</span>
              </div>
            )}
            {isAdmin && license.creator_name && (
              <div className="flex items-center gap-2 text-slate-400 col-span-2">
                <User className="w-4 h-4 text-blue-400" />
                <span>أنشأه: {license.creator_name}</span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-2 pt-3 border-t border-slate-700/50">
            {license.device_serial && (
              <Button
                variant="ghost"
                size="sm"
                className="gap-1.5 text-orange-400 hover:text-orange-300 hover:bg-orange-500/10"
                onClick={() => onResetSerial?.(license.id)}
              >
                <RotateCcw className="w-4 h-4" />
                إعادة ضبط السريال
              </Button>
            )}
            {isAdmin && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-1.5 text-slate-400 hover:text-white hover:bg-slate-700"
                  onClick={() => onEdit?.(license)}
                >
                  <Edit className="w-4 h-4" />
                  تعديل
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  onClick={() => onDelete?.(license.id)}
                >
                  <Trash2 className="w-4 h-4" />
                  حذف
                </Button>
              </>
            )}
          </div>
        </div>
        
        {/* Decorative Element */}
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-tl from-white/5 to-transparent rounded-tl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </CardContent>
    </Card>
  );
}
