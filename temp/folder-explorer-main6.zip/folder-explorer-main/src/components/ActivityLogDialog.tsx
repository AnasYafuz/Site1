import { History, User, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { ActivityLog } from '@/lib/types';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface ActivityLogDialogProps {
  logs: ActivityLog[];
  loading: boolean;
  getActionLabel: (action: string) => string;
}

export function ActivityLogDialog({ logs, loading, getActionLabel }: ActivityLogDialogProps) {
  const getActionColor = (action: string) => {
    switch (action) {
      case 'create_license':
        return 'bg-accent text-accent-foreground';
      case 'update_license':
        return 'bg-info text-info-foreground';
      case 'delete_license':
        return 'bg-destructive text-destructive-foreground';
      case 'reset_serial':
        return 'bg-warning text-warning-foreground';
      default:
        return 'bg-secondary text-secondary-foreground';
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <History className="w-5 h-5" />
          سجل النشاطات
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh]" dir="rtl">
        <DialogHeader>
          <DialogTitle>سجل النشاطات</DialogTitle>
          <DialogDescription>
            جميع العمليات التي قام بها المسؤولين
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[500px] pr-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>لا توجد نشاطات مسجلة</p>
            </div>
          ) : (
            <div className="space-y-4">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{log.user_name}</span>
                    </div>
                    <Badge className={getActionColor(log.action)}>
                      {getActionLabel(log.action)}
                    </Badge>
                  </div>
                  
                  {log.details && (
                    <div className="text-sm text-muted-foreground">
                      {Object.entries(log.details).map(([key, value]) => (
                        <div key={key}>
                          <span className="font-medium">{key}: </span>
                          <span>{String(value)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {format(new Date(log.created_at), 'dd MMM yyyy - HH:mm', { locale: ar })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
