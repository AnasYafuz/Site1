import { useState } from 'react';
import { Shield, MessageCircle, Smartphone, Building2, Server, Ban, AlertTriangle, Eye, Phone, ChevronDown, Sparkles, Zap, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface WelcomePageProps {
  onContinue: () => void;
}

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 24 24">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
);

const features = [
  {
    icon: MessageCircle,
    title: 'فك حظر واتساب الرسمي',
    description: 'إزالة الحظر من تطبيق واتساب الرسمي بشكل آمن وسريع',
    color: 'from-green-500 to-emerald-600',
    iconColor: 'text-green-400',
  },
  {
    icon: Smartphone,
    title: 'فك حظر النسخ المعدلة',
    description: 'دعم كامل لجميع النسخ المعدلة من واتساب',
    color: 'from-blue-500 to-cyan-600',
    iconColor: 'text-blue-400',
  },
  {
    icon: Building2,
    title: 'فك حظر واتساب الأعمال',
    description: 'حلول متكاملة لحسابات واتساب للأعمال',
    color: 'from-purple-500 to-violet-600',
    iconColor: 'text-purple-400',
  },
  {
    icon: Server,
    title: 'فك حظر السيرفر',
    description: 'معالجة حالات الحظر المتعلقة بالسيرفر',
    color: 'from-orange-500 to-amber-600',
    iconColor: 'text-orange-400',
  },
  {
    icon: Ban,
    title: 'حظر مشدد',
    description: 'التعامل مع حالات الحظر المشددة والمعقدة',
    color: 'from-red-500 to-rose-600',
    iconColor: 'text-red-400',
  },
  {
    icon: AlertTriangle,
    title: 'حظر انتهاك',
    description: 'حل مشاكل الحظر بسبب انتهاك الشروط',
    color: 'from-yellow-500 to-orange-600',
    iconColor: 'text-yellow-400',
  },
];

export function WelcomePage({ onContinue }: WelcomePageProps) {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden" dir="rtl">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute top-1/2 -left-40 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" />
        <div className="absolute -bottom-40 right-1/3 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1s' }} />
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Hero Section */}
      <section className="relative z-10 container mx-auto px-4 pt-16 pb-12">
        <div className="text-center space-y-8 animate-slide-up">
          {/* Logo */}
          <div className="relative inline-block">
            <div className="w-32 h-32 mx-auto rounded-3xl bg-gradient-to-br from-primary via-purple-500 to-accent p-1 shadow-2xl shadow-primary/30 animate-float">
              <div className="w-full h-full rounded-3xl bg-slate-900 flex items-center justify-center">
                <div className="text-center">
                  <Shield className="w-12 h-12 text-primary mx-auto" />
                  <span className="text-xl font-bold text-white mt-1 block">AM</span>
                </div>
              </div>
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-accent rounded-full flex items-center justify-center shadow-lg animate-bounce">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
          </div>

          {/* Title */}
          <div className="space-y-4">
            <h1 className="text-5xl md:text-7xl font-black">
              <span className="bg-gradient-to-r from-primary via-purple-400 to-accent bg-clip-text text-transparent">
                AmPro Tool
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
              أداة احترافية متكاملة لفك حظر جميع أنواع حسابات واتساب
            </p>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap justify-center gap-8 pt-4">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white">+10K</div>
              <div className="text-sm text-slate-500">مستخدم نشط</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent">99%</div>
              <div className="text-sm text-slate-500">نسبة النجاح</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary">24/7</div>
              <div className="text-sm text-slate-500">دعم متواصل</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            مميزات الأداة
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card
              key={index}
              className={`group relative overflow-hidden border-0 bg-slate-800/50 backdrop-blur-xl transition-all duration-500 hover:scale-105 hover:shadow-2xl cursor-pointer ${
                hoveredCard === index ? 'shadow-2xl shadow-primary/20' : ''
              }`}
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
              
              <CardContent className="p-6 relative">
                <div className="flex items-start gap-4">
                  {/* Feature Icon with WhatsApp */}
                  <div className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color} p-0.5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center overflow-hidden">
                      <WhatsAppIcon className={`w-8 h-8 ${feature.iconColor}`} />
                    </div>
                  </div>

                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>

                {/* Decorative Element */}
                <div className="absolute bottom-0 right-0 w-20 h-20 bg-gradient-to-tl from-white/5 to-transparent rounded-tl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Feature */}
        <Card className="mt-8 max-w-4xl mx-auto border-0 bg-gradient-to-r from-red-500/10 via-orange-500/10 to-yellow-500/10 backdrop-blur-xl overflow-hidden">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center shadow-lg">
                <Eye className="w-10 h-10 text-white" />
              </div>
              <div className="flex-1 text-center md:text-right">
                <h3 className="text-xl font-bold text-white mb-2">حظر إباحي</h3>
                <p className="text-slate-400">معالجة حالات الحظر المتعلقة بالمحتوى غير المناسب بسرية تامة</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Why Choose Us */}
      <section className="relative z-10 container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-6 rounded-2xl bg-slate-800/30 backdrop-blur border border-slate-700/50">
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/20 flex items-center justify-center">
                <Zap className="w-7 h-7 text-primary" />
              </div>
              <h4 className="font-bold text-white mb-2">سريع وفعال</h4>
              <p className="text-sm text-slate-400">نتائج فورية خلال دقائق معدودة</p>
            </div>
            <div className="text-center p-6 rounded-2xl bg-slate-800/30 backdrop-blur border border-slate-700/50">
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-accent/20 flex items-center justify-center">
                <Lock className="w-7 h-7 text-accent" />
              </div>
              <h4 className="font-bold text-white mb-2">آمن ومضمون</h4>
              <p className="text-sm text-slate-400">حماية كاملة لبياناتك الشخصية</p>
            </div>
            <div className="text-center p-6 rounded-2xl bg-slate-800/30 backdrop-blur border border-slate-700/50">
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Phone className="w-7 h-7 text-purple-400" />
              </div>
              <h4 className="font-bold text-white mb-2">دعم متواصل</h4>
              <p className="text-sm text-slate-400">فريق دعم على مدار الساعة</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="relative z-10 container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="border-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-xl overflow-hidden">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">للتواصل معنا</h3>
              <a
                href="https://wa.me/967777966865"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-lg shadow-lg shadow-green-500/30 hover:shadow-green-500/50 hover:scale-105 transition-all duration-300"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                <span dir="ltr">+967 777 966 865</span>
              </a>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Button */}
      <section className="relative z-10 container mx-auto px-4 py-12 pb-24">
        <div className="text-center">
          <Button
            onClick={onContinue}
            size="lg"
            className="group px-12 py-6 text-xl font-bold rounded-2xl bg-gradient-to-r from-primary via-purple-500 to-accent hover:opacity-90 shadow-2xl shadow-primary/30 hover:shadow-primary/50 transition-all duration-300"
          >
            <span>الدخول للنظام</span>
            <ChevronDown className="w-6 h-6 mr-2 group-hover:translate-y-1 transition-transform" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800 py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-500 text-sm">
            © {new Date().getFullYear()} AmPro Tool - جميع الحقوق محفوظة
          </p>
        </div>
      </footer>
    </div>
  );
}
