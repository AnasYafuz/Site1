import { useState, useMemo } from 'react';
import { Key } from 'lucide-react';
import { License } from '@/lib/types';
import { LicenseCard } from './LicenseCard';
import { LicenseSearch } from './LicenseSearch';
import { EditLicenseDialog } from './EditLicenseDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';

interface LicenseListProps {
  licenses: License[];
  isAdmin: boolean;
  onUpdateLicense: (licenseId: string, updates: Partial<License>) => Promise<{ error?: string | null }>;
  onDeleteLicense: (licenseId: string) => Promise<{ error?: string | null }>;
  onResetSerial: (licenseId: string) => Promise<{ error?: string | null }>;
}

export function LicenseList({ licenses, isAdmin, onUpdateLicense, onDeleteLicense, onResetSerial }: LicenseListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [toolFilter, setToolFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [editingLicense, setEditingLicense] = useState<License | null>(null);
  const [deletingLicenseId, setDeletingLicenseId] = useState<string | null>(null);
  const { toast } = useToast();

  const filteredLicenses = useMemo(() => {
    return licenses.filter((license) => {
      const matchesSearch =
        license.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        license.license_key.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTool = toolFilter === 'all' || license.tool_type === toolFilter;

      const isExpired = new Date(license.expires_at) < new Date();
      const isActive = license.is_active && !isExpired;
      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'active' && isActive) ||
        (statusFilter === 'expired' && !isActive);

      return matchesSearch && matchesTool && matchesStatus;
    });
  }, [licenses, searchQuery, toolFilter, statusFilter]);

  const handleResetSerial = async (licenseId: string) => {
    const result = await onResetSerial(licenseId);
    if (result.error) {
      toast({
        title: 'خطأ',
        description: result.error,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'تم بنجاح',
        description: 'تم إعادة ضبط السريال',
      });
    }
  };

  const handleDelete = async () => {
    if (!deletingLicenseId) return;
    
    const result = await onDeleteLicense(deletingLicenseId);
    if (result.error) {
      toast({
        title: 'خطأ',
        description: result.error,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'تم الحذف',
        description: 'تم حذف الترخيص بنجاح',
      });
    }
    setDeletingLicenseId(null);
  };

  return (
    <div className="space-y-6">
      <LicenseSearch
        onSearch={setSearchQuery}
        onFilterTool={setToolFilter}
        onFilterStatus={setStatusFilter}
        activeFilters={{ tool: toolFilter, status: statusFilter }}
      />

      {filteredLicenses.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-24 h-24 mx-auto mb-6 rounded-3xl bg-gradient-to-br from-primary via-purple-500 to-accent p-0.5 shadow-2xl shadow-primary/30">
            <div className="w-full h-full rounded-3xl bg-slate-900 flex items-center justify-center">
              <Key className="w-12 h-12 text-primary" />
            </div>
          </div>
          <p className="text-xl font-bold text-white mb-2">لا توجد تراخيص</p>
          <p className="text-slate-400">قم بإنشاء ترخيص جديد للبدء</p>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredLicenses.map((license) => (
            <LicenseCard
              key={license.id}
              license={license}
              isAdmin={isAdmin}
              onEdit={setEditingLicense}
              onDelete={setDeletingLicenseId}
              onResetSerial={handleResetSerial}
            />
          ))}
        </div>
      )}

      <EditLicenseDialog
        license={editingLicense}
        open={!!editingLicense}
        onOpenChange={(open) => !open && setEditingLicense(null)}
        onSave={onUpdateLicense}
      />

      <AlertDialog open={!!deletingLicenseId} onOpenChange={(open) => !open && setDeletingLicenseId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا الترخيص؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
