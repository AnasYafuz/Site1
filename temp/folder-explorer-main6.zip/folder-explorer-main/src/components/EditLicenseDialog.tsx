import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { License } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

interface EditLicenseDialogProps {
  license: License | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (licenseId: string, updates: Partial<License>) => Promise<{ error?: string | null }>;
}

export function EditLicenseDialog({ license, open, onOpenChange, onSave }: EditLicenseDialogProps) {
  const [customerName, setCustomerName] = useState('');
  const [licenseKey, setLicenseKey] = useState('');
  const [durationDays, setDurationDays] = useState(30);
  const [isActive, setIsActive] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (license) {
      setCustomerName(license.customer_name);
      setLicenseKey(license.license_key);
      setDurationDays(license.duration_days);
      setIsActive(license.is_active);
    }
  }, [license]);

  const handleSave = async () => {
    if (!license) return;

    setIsLoading(true);
    const result = await onSave(license.id, {
      customer_name: customerName,
      license_key: licenseKey,
      duration_days: durationDays,
      is_active: isActive,
    });
    setIsLoading(false);

    if (result.error) {
      toast({
        title: 'خطأ',
        description: result.error,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'تم الحفظ',
        description: 'تم تحديث الترخيص بنجاح',
      });
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle>تعديل الترخيص</DialogTitle>
          <DialogDescription>
            قم بتعديل بيانات الترخيص
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="editCustomerName">اسم العميل</Label>
            <Input
              id="editCustomerName"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editLicenseKey">مفتاح الترخيص</Label>
            <Input
              id="editLicenseKey"
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
              dir="ltr"
              className="font-mono"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editDuration">مدة الترخيص (بالأيام)</Label>
            <Select value={durationDays.toString()} onValueChange={(v) => setDurationDays(parseInt(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 أيام</SelectItem>
                <SelectItem value="15">15 يوم</SelectItem>
                <SelectItem value="30">30 يوم</SelectItem>
                <SelectItem value="60">60 يوم</SelectItem>
                <SelectItem value="90">90 يوم</SelectItem>
                <SelectItem value="180">180 يوم</SelectItem>
                <SelectItem value="365">سنة</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="editIsActive">الترخيص نشط</Label>
            <Switch
              id="editIsActive"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button onClick={handleSave} disabled={isLoading} className="gradient-primary text-primary-foreground">
            {isLoading ? 'جاري الحفظ...' : 'حفظ التغييرات'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
