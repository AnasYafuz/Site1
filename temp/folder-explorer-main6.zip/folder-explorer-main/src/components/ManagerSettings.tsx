import { useState } from 'react';
import { UserPlus, Users, Edit, Trash2, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Manager } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

interface ManagerSettingsProps {
  managers: Manager[];
  onCreateManager: (email: string, password: string, name: string, maxLicenses: number) => Promise<{ error?: string | null }>;
  onUpdateManager: (managerId: string, updates: { name?: string; max_licenses?: number }) => Promise<{ error?: string | null }>;
  onDeleteManager: (managerId: string) => Promise<{ error?: string | null }>;
}

export function ManagerSettings({ managers, onCreateManager, onUpdateManager, onDeleteManager }: ManagerSettingsProps) {
  const [addOpen, setAddOpen] = useState(false);
  const [editingManager, setEditingManager] = useState<Manager | null>(null);
  const [deletingManagerId, setDeletingManagerId] = useState<string | null>(null);
  
  // Add form
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newName, setNewName] = useState('');
  const [newMaxLicenses, setNewMaxLicenses] = useState(10);
  
  // Edit form
  const [editName, setEditName] = useState('');
  const [editMaxLicenses, setEditMaxLicenses] = useState(10);
  
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newEmail || !newPassword || !newName) {
      toast({
        title: 'خطأ',
        description: 'يرجى ملء جميع الحقول',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await onCreateManager(newEmail, newPassword, newName, newMaxLicenses);
    setIsLoading(false);

    if (result.error) {
      toast({
        title: 'خطأ',
        description: result.error,
        variant: 'destructive',
      });
    } else {
      setAddOpen(false);
      setNewEmail('');
      setNewPassword('');
      setNewName('');
      setNewMaxLicenses(10);
    }
  };

  const openEdit = (manager: Manager) => {
    setEditingManager(manager);
    setEditName(manager.name);
    setEditMaxLicenses(manager.max_licenses);
  };

  const handleEdit = async () => {
    if (!editingManager) return;

    setIsLoading(true);
    const result = await onUpdateManager(editingManager.id, {
      name: editName,
      max_licenses: editMaxLicenses,
    });
    setIsLoading(false);

    if (!result.error) {
      setEditingManager(null);
    }
  };

  const handleDelete = async () => {
    if (!deletingManagerId) return;

    const result = await onDeleteManager(deletingManagerId);
    if (!result.error) {
      setDeletingManagerId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">إدارة المسؤولين</h2>
          <p className="text-sm text-muted-foreground">إضافة وتعديل صلاحيات المسؤولين</p>
        </div>
        
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button className="gradient-primary text-primary-foreground gap-2">
              <UserPlus className="w-5 h-5" />
              إضافة مسؤول
            </Button>
          </DialogTrigger>
          <DialogContent dir="rtl">
            <DialogHeader>
              <DialogTitle>إضافة مسؤول جديد</DialogTitle>
              <DialogDescription>
                أدخل بيانات المسؤول الجديد وحدد عدد التراخيص المسموح له بإنشائها
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="space-y-2">
                <Label>الاسم</Label>
                <Input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="اسم المسؤول"
                />
              </div>
              <div className="space-y-2">
                <Label>البريد الإلكتروني</Label>
                <Input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="email@example.com"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label>كلمة المرور</Label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label>الحد الأقصى للتراخيص</Label>
                <Input
                  type="number"
                  value={newMaxLicenses}
                  onChange={(e) => setNewMaxLicenses(parseInt(e.target.value) || 0)}
                  min={0}
                />
                <p className="text-xs text-muted-foreground">عدد التراخيص التي يمكن للمسؤول إنشاؤها</p>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setAddOpen(false)}>
                  إلغاء
                </Button>
                <Button type="submit" disabled={isLoading} className="gradient-primary text-primary-foreground">
                  {isLoading ? 'جاري الإنشاء...' : 'إنشاء المسؤول'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {managers.length === 0 ? (
        <Card className="glass border-border/50">
          <CardContent className="py-12 text-center text-muted-foreground">
            <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>لا يوجد مسؤولين</p>
            <p className="text-sm">قم بإضافة مسؤول جديد للبدء</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {managers.map((manager) => (
            <Card key={manager.id} className="glass border-border/50">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{manager.name}</CardTitle>
                    <CardDescription>{manager.email}</CardDescription>
                  </div>
                  <Badge variant="secondary">مسؤول</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Key className="w-4 h-4" />
                  <span>
                    التراخيص: {manager.created_licenses_count} / {manager.max_licenses}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-1"
                    onClick={() => openEdit(manager)}
                  >
                    <Edit className="w-4 h-4" />
                    تعديل
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1 text-destructive hover:text-destructive"
                    onClick={() => setDeletingManagerId(manager.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingManager} onOpenChange={(open) => !open && setEditingManager(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>تعديل المسؤول</DialogTitle>
            <DialogDescription>
              تعديل بيانات المسؤول {editingManager?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>الاسم</Label>
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>الحد الأقصى للتراخيص</Label>
              <Input
                type="number"
                value={editMaxLicenses}
                onChange={(e) => setEditMaxLicenses(parseInt(e.target.value) || 0)}
                min={0}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingManager(null)}>
              إلغاء
            </Button>
            <Button onClick={handleEdit} disabled={isLoading} className="gradient-primary text-primary-foreground">
              {isLoading ? 'جاري الحفظ...' : 'حفظ التغييرات'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <AlertDialog open={!!deletingManagerId} onOpenChange={(open) => !open && setDeletingManagerId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف هذا المسؤول؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
