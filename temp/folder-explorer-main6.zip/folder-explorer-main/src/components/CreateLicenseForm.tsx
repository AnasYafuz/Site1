import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface CreateLicenseFormProps {
  onCreateLicense: (customerName: string, toolType: 'AMPro Tool' | 'HI Pro Tool', durationDays: number) => Promise<{ error?: string | null }>;
  canCreate?: boolean;
  remainingLicenses?: number;
}

export function CreateLicenseForm({ onCreateLicense, canCreate = true, remainingLicenses }: CreateLicenseFormProps) {
  const [open, setOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [toolType, setToolType] = useState<'AMPro Tool' | 'HI Pro Tool'>('AMPro Tool');
  const [durationDays, setDurationDays] = useState(30);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim()) {
      toast({
        title: 'خطأ',
        description: 'يرجى إدخال اسم العميل',
        variant: 'destructive',
      });
      return;
    }

    if (!canCreate) {
      toast({
        title: 'خطأ',
        description: 'لقد وصلت للحد الأقصى من التراخيص المسموح بها',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    const result = await onCreateLicense(customerName, toolType, durationDays);
    setIsLoading(false);

    if (result.error) {
      toast({
        title: 'خطأ',
        description: result.error,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'تم بنجاح',
        description: 'تم إنشاء الترخيص بنجاح',
      });
      setOpen(false);
      setCustomerName('');
      setDurationDays(30);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gradient-primary hover:opacity-90 text-primary-foreground gap-2">
          <Plus className="w-5 h-5" />
          إضافة ترخيص
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle>إنشاء ترخيص جديد</DialogTitle>
          <DialogDescription>
            أدخل بيانات الترخيص الجديد
            {remainingLicenses !== undefined && (
              <span className="block mt-1 text-primary">
                التراخيص المتبقية: {remainingLicenses}
              </span>
            )}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="customerName">اسم العميل</Label>
            <Input
              id="customerName"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="أدخل اسم العميل"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="toolType">نوع الأداة</Label>
            <Select value={toolType} onValueChange={(v) => setToolType(v as 'AMPro Tool' | 'HI Pro Tool')}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AMPro Tool">AMPro Tool</SelectItem>
                <SelectItem value="HI Pro Tool">HI Pro Tool</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="durationDays">مدة الترخيص (بالأيام)</Label>
            <Select value={durationDays.toString()} onValueChange={(v) => setDurationDays(parseInt(v))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 أيام</SelectItem>
                <SelectItem value="15">15 يوم</SelectItem>
                <SelectItem value="30">30 يوم</SelectItem>
                <SelectItem value="60">60 يوم</SelectItem>
                <SelectItem value="90">90 يوم</SelectItem>
                <SelectItem value="180">180 يوم</SelectItem>
                <SelectItem value="365">سنة</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
            <Button type="submit" disabled={isLoading || !canCreate} className="gradient-primary text-primary-foreground">
              {isLoading ? 'جاري الإنشاء...' : 'إنشاء الترخيص'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
