import { useState } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

interface LicenseSearchProps {
  onSearch: (query: string) => void;
  onFilterTool: (tool: string) => void;
  onFilterStatus: (status: string) => void;
  activeFilters: {
    tool: string;
    status: string;
  };
}

export function LicenseSearch({ onSearch, onFilterTool, onFilterStatus, activeFilters }: LicenseSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    onSearch(value);
  };

  const clearFilters = () => {
    setSearchQuery('');
    onSearch('');
    onFilterTool('all');
    onFilterStatus('all');
  };

  const hasActiveFilters = activeFilters.tool !== 'all' || activeFilters.status !== 'all' || searchQuery;

  return (
    <div className="space-y-3">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            placeholder="بحث بالاسم أو مفتاح الترخيص..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pr-10 bg-slate-800/50 border-slate-700/50 text-white placeholder:text-slate-500 focus:border-primary"
          />
        </div>
        <Button
          variant="outline"
          onClick={() => setShowFilters(!showFilters)}
          className="gap-2 bg-slate-800/50 border-slate-700/50 text-slate-300 hover:bg-slate-700 hover:text-white"
        >
          <Filter className="w-4 h-4" />
          الفلاتر
          {hasActiveFilters && (
            <Badge className="mr-1 bg-gradient-to-r from-primary to-purple-600 text-white border-0">
              نشط
            </Badge>
          )}
        </Button>
      </div>

      {showFilters && (
        <div className="flex flex-wrap gap-3 p-4 bg-slate-800/30 rounded-xl border border-slate-700/50 backdrop-blur animate-fade-in">
          <Select value={activeFilters.tool} onValueChange={onFilterTool}>
            <SelectTrigger className="w-40 bg-slate-900/50 border-slate-700/50 text-white">
              <SelectValue placeholder="نوع الأداة" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              <SelectItem value="all">جميع الأدوات</SelectItem>
              <SelectItem value="AMPro Tool">AMPro Tool</SelectItem>
              <SelectItem value="HI Pro Tool">HI Pro Tool</SelectItem>
            </SelectContent>
          </Select>

          <Select value={activeFilters.status} onValueChange={onFilterStatus}>
            <SelectTrigger className="w-40 bg-slate-900/50 border-slate-700/50 text-white">
              <SelectValue placeholder="الحالة" />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700">
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="active">نشط</SelectItem>
              <SelectItem value="expired">منتهي</SelectItem>
            </SelectContent>
          </Select>

          {hasActiveFilters && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearFilters} 
              className="gap-1 text-slate-400 hover:text-white hover:bg-slate-700"
            >
              <X className="w-4 h-4" />
              مسح الفلاتر
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
