import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface StatCardProps {
  title: string;
  value: number | string;
  icon: LucideIcon;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
  className?: string;
  iconClassName?: string;
  gradient?: string;
}

export function StatCard({
  title,
  value,
  icon: Icon,
  description,
  className,
  iconClassName,
  gradient = 'from-primary to-purple-600',
}: StatCardProps) {
  return (
    <Card className={cn(
      'group relative overflow-hidden border-0 bg-slate-800/50 backdrop-blur-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-primary/20',
      className
    )}>
      <div className={cn('absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-10 transition-opacity duration-500', gradient)} />
      
      <CardContent className="p-6 relative">
        <div className="flex items-center gap-4">
          <div className={cn(
            'w-14 h-14 rounded-2xl bg-gradient-to-br p-0.5 shadow-lg group-hover:scale-110 transition-transform duration-300',
            gradient
          )}>
            <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center">
              <Icon className={cn('w-7 h-7 text-white', iconClassName)} />
            </div>
          </div>
          
          <div className="flex-1">
            <p className="text-sm text-slate-400 mb-1">{title}</p>
            <p className="text-3xl font-bold text-white">{value}</p>
            {description && (
              <p className="text-xs text-slate-500 mt-1">{description}</p>
            )}
          </div>
        </div>
        
        {/* Decorative Element */}
        <div className="absolute bottom-0 right-0 w-20 h-20 bg-gradient-to-tl from-white/5 to-transparent rounded-tl-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </CardContent>
    </Card>
  );
}
