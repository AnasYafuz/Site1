import { LogOut, Key, Users, CheckCircle, XCircle, RefreshCw, Settings, Shield, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { StatCard } from './StatCard';
import { CreateLicenseForm } from './CreateLicenseForm';
import { LicenseList } from './LicenseList';
import { ManagerSettings } from './ManagerSettings';
import { ActivityLogDialog } from './ActivityLogDialog';
import { ExportImportButtons } from './ExportImportButtons';
import { useLicenses } from '@/hooks/useLicenses';
import { useManagers } from '@/hooks/useManagers';
import { useActivityLogs } from '@/hooks/useActivityLogs';
import { useAuth } from '@/hooks/useAuth';

export function Dashboard() {
  const { user, signOut, isAdmin, profileName } = useAuth();
  const { licenses, loading, stats, createLicense, updateLicense, resetDeviceSerial, deleteLicense, fetchLicenses } = useLicenses(user?.id, isAdmin);
  const { managers, createManager, updateManager, deleteManager } = useManagers();
  const { logs, loading: logsLoading, getActionLabel } = useActivityLogs(isAdmin);

  const handleImport = async (importedLicenses: { customer_name: string; tool_type: 'AMPro Tool' | 'HI Pro Tool'; duration_days: number }[]) => {
    for (const license of importedLicenses) {
      await createLicense(license.customer_name, license.tool_type, license.duration_days);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden" dir="rtl">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute top-1/2 -left-40 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" />
        <div className="absolute -bottom-40 right-1/3 w-72 h-72 bg-purple-500/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1s' }} />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-900/80 border-b border-slate-700/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary via-purple-500 to-accent p-0.5 shadow-lg shadow-primary/30">
                  <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center">
                    <Shield className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-accent rounded-full flex items-center justify-center shadow-lg">
                  <Sparkles className="w-3 h-3 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-purple-400 to-accent bg-clip-text text-transparent">
                  نظام إدارة التراخيص
                </h1>
                <p className="text-sm text-slate-400">مرحباً، {profileName || user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={fetchLicenses}
                className="text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <RefreshCw className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                onClick={signOut} 
                className="gap-2 text-red-400 hover:text-red-300 hover:bg-red-500/10"
              >
                <LogOut className="w-5 h-5" />
                <span className="hidden sm:inline">خروج</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8 space-y-8">
        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <StatCard 
            title="إجمالي التراخيص" 
            value={stats.total_licenses} 
            icon={Key}
            gradient="from-primary to-purple-600"
          />
          <StatCard 
            title="التراخيص النشطة" 
            value={stats.active_licenses} 
            icon={CheckCircle}
            gradient="from-green-500 to-emerald-600"
          />
          <StatCard 
            title="التراخيص المنتهية" 
            value={stats.expired_licenses} 
            icon={XCircle}
            gradient="from-red-500 to-rose-600"
          />
          <StatCard 
            title="مستخدمي AMPro" 
            value={stats.ampro_users} 
            icon={Users}
            gradient="from-blue-500 to-cyan-600"
          />
          <StatCard 
            title="مستخدمي HI Pro" 
            value={stats.hipro_users} 
            icon={Users}
            gradient="from-orange-500 to-amber-600"
          />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="licenses" className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <TabsList className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-xl p-1">
              <TabsTrigger 
                value="licenses" 
                className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <Key className="w-4 h-4" />
                التراخيص
              </TabsTrigger>
              {isAdmin && (
                <TabsTrigger 
                  value="managers" 
                  className="gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-purple-600 data-[state=active]:text-white"
                >
                  <Settings className="w-4 h-4" />
                  المسؤولين
                </TabsTrigger>
              )}
            </TabsList>

            <div className="flex flex-wrap gap-2">
              {isAdmin && <ActivityLogDialog logs={logs} loading={logsLoading} getActionLabel={getActionLabel} />}
              <ExportImportButtons licenses={licenses} onImport={isAdmin ? handleImport : undefined} isAdmin={isAdmin} />
              <CreateLicenseForm onCreateLicense={createLicense} />
            </div>
          </div>

          <TabsContent value="licenses" className="mt-0">
            {loading ? (
              <div className="flex items-center justify-center py-16">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              <LicenseList
                licenses={licenses}
                isAdmin={isAdmin}
                onUpdateLicense={updateLicense}
                onDeleteLicense={deleteLicense}
                onResetSerial={resetDeviceSerial}
              />
            )}
          </TabsContent>

          {isAdmin && (
            <TabsContent value="managers" className="mt-0">
              <ManagerSettings
                managers={managers}
                onCreateManager={createManager}
                onUpdateManager={updateManager}
                onDeleteManager={deleteManager}
              />
            </TabsContent>
          )}
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800 py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-slate-500 text-sm">
            © {new Date().getFullYear()} AmPro Tool - جميع الحقوق محفوظة
          </p>
        </div>
      </footer>
    </div>
  );
}
