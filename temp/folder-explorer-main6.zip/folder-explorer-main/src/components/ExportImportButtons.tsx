import { Download, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { License } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useRef } from 'react';

interface ExportImportButtonsProps {
  licenses: License[];
  onImport?: (licenses: { customer_name: string; tool_type: 'AMPro Tool' | 'HI Pro Tool'; duration_days: number }[]) => Promise<void>;
  isAdmin: boolean;
}

export function ExportImportButtons({ licenses, onImport, isAdmin }: ExportImportButtonsProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const exportToCSV = () => {
    const headers = ['مفتاح الترخيص', 'اسم العميل', 'نوع الأداة', 'المدة (أيام)', 'تاريخ الانتهاء', 'الحالة', 'السريال'];
    const rows = licenses.map((license) => [
      license.license_key,
      license.customer_name,
      license.tool_type,
      license.duration_days,
      new Date(license.expires_at).toLocaleDateString('ar-EG'),
      license.is_active && new Date(license.expires_at) > new Date() ? 'نشط' : 'منتهي',
      license.device_serial || '-',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.join(','))
      .join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `licenses_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: 'تم التصدير',
      description: `تم تصدير ${licenses.length} ترخيص`,
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onImport) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter((line) => line.trim());
        
        // Skip header
        const dataLines = lines.slice(1);
        
        const importedLicenses = dataLines.map((line) => {
          const [, customerName, toolType, durationDays] = line.split(',');
          return {
            customer_name: customerName?.trim() || '',
            tool_type: (toolType?.trim() === 'HI Pro Tool' ? 'HI Pro Tool' : 'AMPro Tool') as 'AMPro Tool' | 'HI Pro Tool',
            duration_days: parseInt(durationDays?.trim()) || 30,
          };
        }).filter((l) => l.customer_name);

        if (importedLicenses.length === 0) {
          toast({
            title: 'خطأ',
            description: 'لم يتم العثور على بيانات صالحة للاستيراد',
            variant: 'destructive',
          });
          return;
        }

        await onImport(importedLicenses);
        
        toast({
          title: 'تم الاستيراد',
          description: `تم استيراد ${importedLicenses.length} ترخيص`,
        });
      } catch (error) {
        toast({
          title: 'خطأ',
          description: 'فشل في قراءة الملف',
          variant: 'destructive',
        });
      }
    };
    
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="flex gap-2">
      <Button variant="outline" onClick={exportToCSV} className="gap-2">
        <Download className="w-4 h-4" />
        تصدير
      </Button>
      
      {isAdmin && onImport && (
        <>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.xls"
            onChange={handleFileChange}
            className="hidden"
          />
          <Button
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            className="gap-2"
          >
            <Upload className="w-4 h-4" />
            استيراد
          </Button>
        </>
      )}
    </div>
  );
}
