export type AppRole = 'admin' | 'manager';

export interface Profile {
  id: string;
  email: string;
  name: string;
  max_licenses: number;
  created_licenses_count: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface License {
  id: string;
  license_key: string;
  customer_name: string;
  tool_type: 'AMPro Tool' | 'HI Pro Tool';
  device_serial: string | null;
  duration_days: number;
  expires_at: string;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  creator_name?: string;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  action: string;
  details: Record<string, unknown> | null;
  target_license_id: string | null;
  created_at: string;
  user_name?: string;
}

export interface UserRole {
  id: string;
  user_id: string;
  role: AppRole;
  created_at: string;
}

export interface Stats {
  total_licenses: number;
  active_licenses: number;
  expired_licenses: number;
  ampro_users: number;
  hipro_users: number;
}

export interface Manager {
  id: string;
  email: string;
  name: string;
  max_licenses: number;
  created_licenses_count: number;
  created_at: string;
}
