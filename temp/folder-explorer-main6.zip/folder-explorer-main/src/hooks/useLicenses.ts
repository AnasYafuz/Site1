import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { License, Stats } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

export function useLicenses(userId: string | undefined, isAdmin: boolean) {
  const [licenses, setLicenses] = useState<License[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({
    total_licenses: 0,
    active_licenses: 0,
    expired_licenses: 0,
    ampro_users: 0,
    hipro_users: 0,
  });
  const { toast } = useToast();

  const fetchLicenses = useCallback(async () => {
    if (!userId) return;

    setLoading(true);
    try {
      let query = supabase
        .from('licenses')
        .select('*')
        .order('created_at', { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching licenses:', error);
        toast({
          title: 'خطأ',
          description: 'فشل في جلب التراخيص',
          variant: 'destructive',
        });
        return;
      }

      // Fetch creator names for admin
      let licensesWithCreators = data || [];
      if (isAdmin && data) {
        const creatorIds = [...new Set(data.map(l => l.created_by))];
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, name')
          .in('id', creatorIds);

        const profileMap = new Map(profiles?.map(p => [p.id, p.name]) || []);
        licensesWithCreators = data.map(license => ({
          ...license,
          creator_name: profileMap.get(license.created_by) || 'غير معروف',
        }));
      }

      setLicenses(licensesWithCreators as License[]);

      // Calculate stats
      const now = new Date();
      const active = data?.filter(l => l.is_active && new Date(l.expires_at) > now) || [];
      const expired = data?.filter(l => !l.is_active || new Date(l.expires_at) <= now) || [];
      const ampro = data?.filter(l => l.tool_type === 'AMPro Tool') || [];
      const hipro = data?.filter(l => l.tool_type === 'HI Pro Tool') || [];

      setStats({
        total_licenses: data?.length || 0,
        active_licenses: active.length,
        expired_licenses: expired.length,
        ampro_users: ampro.length,
        hipro_users: hipro.length,
      });
    } catch (err) {
      console.error('Error in fetchLicenses:', err);
    } finally {
      setLoading(false);
    }
  }, [userId, isAdmin, toast]);

  useEffect(() => {
    fetchLicenses();
  }, [fetchLicenses]);

  const generateLicenseKey = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = 4;
    const segmentLength = 4;
    const parts = [];

    for (let i = 0; i < segments; i++) {
      let segment = '';
      for (let j = 0; j < segmentLength; j++) {
        segment += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      parts.push(segment);
    }

    return parts.join('-');
  };

  const createLicense = async (
    customerName: string,
    toolType: 'AMPro Tool' | 'HI Pro Tool',
    durationDays: number
  ) => {
    if (!userId) return { error: 'لم يتم تسجيل الدخول' };

    const licenseKey = generateLicenseKey();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + durationDays);

    const { data, error } = await supabase
      .from('licenses')
      .insert({
        license_key: licenseKey,
        customer_name: customerName,
        tool_type: toolType,
        duration_days: durationDays,
        expires_at: expiresAt.toISOString(),
        created_by: userId,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating license:', error);
      return { error: error.message };
    }

    // Update profile license count
    try {
      await supabase
        .from('profiles')
        .update({ created_licenses_count: licenses.length + 1 })
        .eq('id', userId);
    } catch (e) {
      console.error('Error updating license count:', e);
    }

    // Log activity
    await supabase.from('activity_logs').insert({
      user_id: userId,
      action: 'create_license',
      details: { license_key: licenseKey, customer_name: customerName },
      target_license_id: data.id,
    });

    await fetchLicenses();
    return { data, error: null };
  };

  const updateLicense = async (
    licenseId: string,
    updates: Partial<Pick<License, 'customer_name' | 'license_key' | 'duration_days' | 'device_serial' | 'is_active'>>
  ) => {
    if (!userId) return { error: 'لم يتم تسجيل الدخول' };

    const updateData: Record<string, unknown> = { ...updates };

    if (updates.duration_days) {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + updates.duration_days);
      updateData.expires_at = expiresAt.toISOString();
    }

    const { data, error } = await supabase
      .from('licenses')
      .update(updateData)
      .eq('id', licenseId)
      .select()
      .single();

    if (error) {
      console.error('Error updating license:', error);
      return { error: error.message };
    }

    // Log activity
    await supabase.from('activity_logs').insert({
      user_id: userId,
      action: 'update_license',
      details: updates,
      target_license_id: licenseId,
    });

    await fetchLicenses();
    return { data, error: null };
  };

  const resetDeviceSerial = async (licenseId: string) => {
    return updateLicense(licenseId, { device_serial: null });
  };

  const deleteLicense = async (licenseId: string) => {
    if (!userId) return { error: 'لم يتم تسجيل الدخول' };

    // Log before delete
    await supabase.from('activity_logs').insert({
      user_id: userId,
      action: 'delete_license',
      details: { license_id: licenseId },
    });

    const { error } = await supabase
      .from('licenses')
      .delete()
      .eq('id', licenseId);

    if (error) {
      console.error('Error deleting license:', error);
      return { error: error.message };
    }

    await fetchLicenses();
    return { error: null };
  };

  return {
    licenses,
    loading,
    stats,
    fetchLicenses,
    createLicense,
    updateLicense,
    resetDeviceSerial,
    deleteLicense,
    generateLicenseKey,
  };
}
