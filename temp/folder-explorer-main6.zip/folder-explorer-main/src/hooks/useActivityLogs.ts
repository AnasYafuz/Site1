import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ActivityLog } from '@/lib/types';

export function useActivityLogs(isAdmin: boolean) {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLogs = useCallback(async () => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) {
        console.error('Error fetching activity logs:', error);
        return;
      }

      // Fetch user names
      if (data && data.length > 0) {
        const userIds = [...new Set(data.map(log => log.user_id))];
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, name')
          .in('id', userIds);

        const profileMap = new Map(profiles?.map(p => [p.id, p.name]) || []);
        const logsWithNames = data.map(log => ({
          ...log,
          user_name: profileMap.get(log.user_id) || 'غير معروف',
        }));

        setLogs(logsWithNames as ActivityLog[]);
      } else {
        setLogs([]);
      }
    } catch (err) {
      console.error('Error in fetchLogs:', err);
    } finally {
      setLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const getActionLabel = (action: string) => {
    const labels: Record<string, string> = {
      create_license: 'إنشاء ترخيص',
      update_license: 'تحديث ترخيص',
      delete_license: 'حذف ترخيص',
      reset_serial: 'إعادة ضبط السريال',
    };
    return labels[action] || action;
  };

  return {
    logs,
    loading,
    fetchLogs,
    getActionLabel,
  };
}
