import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Manager } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

export function useManagers() {
  const [managers, setManagers] = useState<Manager[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchManagers = useCallback(async () => {
    setLoading(true);
    try {
      // Get all users with manager role
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'manager');

      if (rolesError) {
        console.error('Error fetching manager roles:', rolesError);
        return;
      }

      if (!roles || roles.length === 0) {
        setManagers([]);
        setLoading(false);
        return;
      }

      const managerIds = roles.map(r => r.user_id);

      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .in('id', managerIds);

      if (profilesError) {
        console.error('Error fetching manager profiles:', profilesError);
        return;
      }

      setManagers(profiles as Manager[]);
    } catch (err) {
      console.error('Error in fetchManagers:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchManagers();
  }, [fetchManagers]);

  const createManager = async (email: string, password: string, name: string, maxLicenses: number) => {
    try {
      // Create user via edge function or direct signup
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { name },
        },
      });

      if (authError) {
        return { error: authError.message };
      }

      if (!authData.user) {
        return { error: 'فشل في إنشاء المستخدم' };
      }

      // Update profile with max_licenses
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          max_licenses: maxLicenses,
          name,
        })
        .eq('id', authData.user.id);

      if (profileError) {
        console.error('Error updating profile:', profileError);
      }

      // Add manager role
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role: 'manager',
        });

      if (roleError) {
        console.error('Error adding role:', roleError);
        return { error: 'فشل في إضافة صلاحية المسؤول' };
      }

      toast({
        title: 'تم بنجاح',
        description: `تم إنشاء المسؤول ${name}`,
      });

      await fetchManagers();
      return { data: authData.user, error: null };
    } catch (err) {
      console.error('Error creating manager:', err);
      return { error: 'حدث خطأ غير متوقع' };
    }
  };

  const updateManager = async (managerId: string, updates: { name?: string; max_licenses?: number }) => {
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', managerId);

    if (error) {
      console.error('Error updating manager:', error);
      return { error: error.message };
    }

    toast({
      title: 'تم التحديث',
      description: 'تم تحديث بيانات المسؤول',
    });

    await fetchManagers();
    return { error: null };
  };

  const deleteManager = async (managerId: string) => {
    // Delete role first
    const { error: roleError } = await supabase
      .from('user_roles')
      .delete()
      .eq('user_id', managerId);

    if (roleError) {
      console.error('Error deleting role:', roleError);
      return { error: roleError.message };
    }

    toast({
      title: 'تم الحذف',
      description: 'تم حذف المسؤول',
    });

    await fetchManagers();
    return { error: null };
  };

  return {
    managers,
    loading,
    fetchManagers,
    createManager,
    updateManager,
    deleteManager,
  };
}
