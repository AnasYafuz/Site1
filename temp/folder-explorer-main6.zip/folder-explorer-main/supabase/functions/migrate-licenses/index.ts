import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Firebase licenses data
const firebaseLicenses = {
  "0030":{"createdAt":"2025-11-26T23:43:27Z","expiresAt":"2030/01/01","hwid":"35DDC1EE4705C12D14D7E92143E33D19FA0E1F5A0E7AC8277CA31F15E546EC51","licenseKey":"0030","notes":"Generated from Tool","used":false,"userName":"شهاب القملي"},
  "123":{"createdAt":"1447-07-05T11:43:03Z","expiresAt":"2026/7/25","hwid":"57C5F1E40FE7318F43A8865B80C8F88EBBD75B65C96AC4C36FCE5D53B3891329","notes":"Generated from Tool","used":false,"userName":"jj"},
  "8520":{"createdAt":"2025-11-27T17:46:40Z","expiresAt":"2026/11/27","hwid":"94FC68EDE1B77D11ACA517DD94B73A7818FF3E1019D1E6432BF26038F5ADB381","notes":"Generated from Tool","used":false,"userName":"مروان الحاج"},
  "73550":{"createdAt":"2025-12-02T09:38:46Z","expiresAt":"2030/01/01","hwid":"791609A066BDF5D831D9A6CC1B4287A28D2CAC8B3FEA3B149C1B258F5E988884","notes":"Generated from Tool","used":false,"userName":"المطور انس"},
  "77919":{"createdAt":"2025-11-30T21:47:07Z","expiresAt":"2025-12-31","hwid":"1841EC9A283761E0E3D63F8ECE5248AAAEC7BF81838D0C2370BFB05179B14DFD","notes":"Generated from Tool","used":false,"userName":"عدنان الهمداني"},
  "774411":{"createdAt":"2025-11-27T16:27:31Z","expiresAt":"2026/11/27","hwid":"27203E16DCB1462E64EB225A193A0E4DFD76739F81E86B9A0B05D5C8CB11EED0","licenseKey":"774411","notes":"Generated from Tool","used":false,"userName":"اسامه الجرادي"},
  "778899":{"createdAt":"2025-11-27T15:53:44Z","expiresAt":"2026/11/27","hwid":"","notes":"Generated from Tool","used":false,"userName":"عمار العواضي"},
  "00998877":{"createdAt":"2025-12-06T08:59:09.055Z","expiresAt":"2026-12-05","hwid":"6BCD4FA15BBF8A90CE80452B4D63FF10732D04DF96EF10F8075DD2A97C888DC3","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"طه"},
  "7777633":{"createdAt":"2025-11-25T03:08:39Z","expiresAt":"2040-09-24","hwid":"A4ED97774651995B09083309A06BA5F6E8402CBF7E571CCE476ED8230340A763","licenseKey":"7777633","notes":"Official Agent","used":false,"userName":"علي الهمداني"},
  "19995800":{"createdAt":"2025-11-27T20:55:53Z","expiresAt":"2026/11/27","hwid":"43A85D45C138D30D6638B6343FE941DB139779A292226C692245843B236B0194","notes":"Generated from Tool","used":false,"userName":"محمد السقاف"},
  "55226633":{"createdAt":"2025-11-30T17:19:01Z","expiresAt":"2026-12-16","hwid":"664E9FC8A4539F635D15475B37A61C5CEFB057C5025C78475A1E7A1FF706D3A1","notes":"Generated from Tool","used":false,"userName":"محمد عبده"},
  "77897789":{"createdAt":"2025-12-27T08:52:41.448Z","expiresAt":"2026-12-29","hwid":"35CD5C7124DB6412C53A83B7691B11829190441AD083439033AB952FFFE46C90","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"هادي القناص"},
  "78132278":{"createdAt":"2025-12-29T16:59:17.981Z","expiresAt":"2026-12-29","hwid":"2BB39F674D56FD3B3C9FD51FC4C8D4519E144BCE51AF032741DBF266AC5D9651","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"عبدالملك قاسم"},
  "115097647":{"createdAt":"2025-11-27T18:39:39Z","expiresAt":"2026/11/27","hwid":"","notes":"Generated from Tool","used":false,"userName":"عمر خليفه"},
  "711024639":{"createdAt":"2025-11-29T21:58:35Z","expiresAt":"2026/11/30","hwid":"734AAA945504ED8F35006DED99E36BF9527F637C7CA3722580C2DC3A27D50B22","notes":"Generated from Tool","used":false,"userName":"ماجد الشرعبي"},
  "714282401":{"createdAt":"2025-12-10T19:09:44.71Z","expiresAt":"2026-12-10","hwid":"503395B98172D31A6210EB04E1CEEF036DC4D93EC6A036909E94FDD7B5892F80","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"علاء المقرمي"},
  "735040852":{"createdAt":"2025-11-30T13:27:28Z","expiresAt":"2026/11/30","hwid":"FAC0C302CD1AA5F610C0E3E384FC5635545A8D6D6A0234691431EDB563E4CB61","notes":"Generated from Tool","used":false,"userName":"MR.ROBOT"},
  "738185008":{"createdAt":"2025-12-06T10:44:22.991Z","expiresAt":"2026-12-06","hwid":"9BB983B79580538C9567420DA903FA9953A0AD2D34F9315E200D9AB457074AAC","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"Osama"},
  "770677242":{"createdAt":"2025-12-04T17:11:34.131Z","expiresAt":"2026-12-04","hwid":"","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"الهيثم"},
  "770812505":{"createdAt":"2025-12-04T23:34:53.654Z","expiresAt":"2026-12-05","hwid":"2AFD5132725FBE7F7BC333CA3C38D9296EC7F6AEB7D40E4FAF1BFE50F65123B0","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"علي"},
  "770937093":{"createdAt":"2025-12-19T23:37:33.291Z","expiresAt":"2026-12-19","hwid":"251A7ECABF5BF6ADB637BB46C7BD4BDD662BC017FC303515AAE36ADCB440BD20","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"ابو تميم"},
  "771080007":{"createdAt":"2025-12-03T14:29:01.172Z","expiresAt":"2026-12-03","hwid":"8ECAA7A0AE22954728B97AD202144B26934B86FE34594C0DB1E2C404A50FE2BD","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"صالح العصري"},
  "771257428":{"createdAt":"2025-12-04T23:40:35.552Z","expiresAt":"2026-12-05","hwid":"C21409FF4A239905D04D7E9E2AF32C3459624C2C70A96CFD04670A8BFDA5AC26","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"مازن"},
  "772701222":{"expiresAt":"2029-10-23","hwid":"7D2A56B9477E55FDA7CDC9D2FC704E2B1CC384DAB08614E6B3AB5C653A2316E6","notes":"","used":false,"userName":"انس بن مالك"},
  "772942993":{"createdAt":"2025-12-06T11:56:36.68Z","expiresAt":"2026-12-06","hwid":"78AB124737203BF0F7A4B2C7A1F0FE5CFAEA8C881E7BC078B786A5C3A9B03750","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"يوسف"},
  "774222840":{"createdAt":"2025-12-04T15:39:16.297Z","expiresAt":"2026-12-04","hwid":"744AFEF38F96146BA8BC157A51F6A8A2A1086DAACA51A5568C468E27195B3DD0","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"اكرم"},
  "774488941":{"createdAt":"2025-12-08T00:29:55.805Z","expiresAt":"2026-12-08","hwid":"343E169FDCC6A82227AC50265DFFFD7FB5581037EB76BEB7252CDA0A93F7A642","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"علي"},
  "774827631":{"createdAt":"2025-12-21T16:04:00.504Z","expiresAt":"2026-12-21","hwid":"8EA71C2918B0CBF4991BEC09F70707DFE20E055466668B8EF1A5607546FBEE58","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"ابو اوس"},
  "775263314":{"createdAt":"2025-11-29T15:12:17Z","expiresAt":"2026/11/29","hwid":"FF358CB459AE7F547BCA7939750F9397BFF1948E24DF5EF7B4D98380973ED346","notes":"Generated from Tool","used":false,"userName":"كثير انور"},
  "775286921":{"createdAt":"2025-12-08T08:44:09.181Z","expiresAt":"2026-12-08","hwid":"","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"محمد المحجري"},
  "776333706":{"createdAt":"2025-11-30T13:54:09Z","expiresAt":"2026/11/30","hwid":"A67D69547C10037C06573C9DECF3FD906ACFCC4129EF89ACC524F19EA58D9405","notes":"Generated from Tool","used":false,"userName":"رياض الوعل"},
  "776346584":{"createdAt":"2025-11-29T09:44:26Z","expiresAt":"2026/11/29","hwid":"A7C1519AB9877674EE8BF0A6F690069094E962CB8656EB156EAEDDF9FC1A50DD","notes":"Generated from Tool","used":false,"userName":"عمار محروس"},
  "777093695":{"createdAt":"2025-11-29T09:34:41Z","expiresAt":"2026/11/29","hwid":"46545F8C5AD5444C7C693993A61B7AFE614CC208433360D7D6C0B24688B0C51A","notes":"Generated from Tool","used":false,"userName":"عبدالعزيز"},
  "777353208":{"createdAt":"2025-11-27T13:47:53Z","expiresAt":"2030/01/01","hwid":"CD67F011A5D8DC7AD73CDC92E84BE0642BE59739680C5849980EDF5ACCA3B90F","notes":"Generated from Tool","used":false,"userName":"عمار زنجي"},
  "777932822":{"createdAt":"2025-12-30T15:59:18Z","expiresAt":"2026/12/31","hwid":"7486C81F117BC7769FA90ABDC1CDD2A80D0FD18CDD1199C9E63E08C48BD6759F","notes":"Generated from Tool","used":false,"userName":"مروان البروي"},
  "779800998":{"createdAt":"2025-12-02T17:30:07Z","expiresAt":"2026/12/2","hwid":"8A1694622447E8C62D12740B3FAAEABA2C5FCBE8770813914A8F445DEDB04F55","notes":"Generated from Tool","used":false,"userName":"king2026"},
  "779859811":{"createdAt":"2025-11-30T13:16:20Z","expiresAt":"2026/11/30","hwid":"1219B1C575B61DC6559049B2C863D468E5B8B04811E2D1845E738A410A5B3340","notes":"Generated from Tool","used":false,"userName":"سليمان الشرعبي"},
  "782111550":{"createdAt":"2025-12-03T12:49:20.619Z","expiresAt":"2026-12-03","hwid":"","notes":"الملوك","used":false,"userName":"محمد المحجري"},
  "782554227":{"createdAt":"2025-12-06T13:34:57.027Z","expiresAt":"2026-12-06","hwid":"08C2A722640577CE3C7477C9297D8952956C602808632793C217F007644EC0E1","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"وائل شكري"},
  "782939935":{"createdAt":"2025-11-28T15:57:13Z","expiresAt":"2026/11/28","hwid":"7E36DAC9A648ACDD05FAA273D50967C70CD754032F7020A1F691013C3D99947A","notes":"Generated from Tool","used":false,"userName":"مازن مطهر"},
  "935067961":{"createdAt":"2025-12-14T00:01:24.342Z","expiresAt":"2026-12-13","hwid":"3A64D1E44B9608F06D7F6570EC53E4161C50F535DEC9136CB86383C4BDE1A5E6","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"محمد كلزه"},
  "936031489":{"createdAt":"2025-12-16T16:23:05.658Z","expiresAt":"2026-12-16","hwid":"32E232B4A4A4EABC073666F2FFAAEC99C9B0D832257028C5B57E1DD30094CD78","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"عبيده عنان"},
  "937540657":{"createdAt":"2025-12-02T11:57:48Z","expiresAt":"2026/12/02","hwid":"0F8359FFDBE92CD4FA0B9A468BD1E427034AB40BAE06D43C58F3C2A90FF6019F","notes":"Generated from Tool","used":false,"userName":"ZKERT"},
  "938158547":{"createdAt":"2025-11-27T13:51:42Z","expiresAt":"2026/11/27","hwid":"CFEB05BCC7E16704535C4E668466F69E5128DED6AD6D2CCBE3C2CB2B81DEF4DF","licenseKey":"938158547","notes":"Generated from Tool","used":false,"userName":"ماهر"},
  "939945567":{"createdAt":"2025-12-22T14:40:47.043Z","expiresAt":"2026-12-22","hwid":"ABF8077989DA655ED4917D160990AAE54C4F9A1811346CB036E8A6FC8851985D","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"ابو اسلام"},
  "991581336":{"createdAt":"2025-11-30T15:41:07Z","expiresAt":"2026/11/30","hwid":"791609A066BDF5D831D9A6CC1B4287A28D2CAC8B3FEA3B149C1B258F5E988884","notes":"Generated from Tool","used":false,"userName":"شبل حمدان"},
  "000999333777":{"createdAt":"2025-12-07T20:41:46.027Z","expiresAt":"2026-12-08","hwid":"C325F08A0A89F174B76DCD1BF2308B27B76B918C20A3F8411E5644D4EFA00F16","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"شادي انور"},
  "01016905836":{"createdAt":"2025-12-24T15:23:27.871Z","expiresAt":"2026-12-24","hwid":"2101F5FE48F4D14F143213507A3B1F0BB0F6F538CCD1DD669E51BFD0B69B472F","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"محمد سعيد"},
  "1156393566":{"createdAt":"2025-11-27T19:52:24Z","expiresAt":"2026/11/28","hwid":"BDB1FC90A00B9011F9F285DF5B46C0821672DA7E4F752E1958B523C9D2DDE104","notes":"Generated from Tool","used":false,"userName":"اسكولر"},
  "05358341477":{"createdAt":"2025-11-28T17:52:10Z","expiresAt":"2026/11/28","hwid":"4A9A3CD8E22E26276661C8DFE3CB2180161A6E94F1975976816375C537ED5735","notes":"Generated from Tool","used":false,"userName":"mehmet"},
  "5396956440":{"createdAt":"2025-11-30T20:58:44Z","expiresAt":"2026/12/01","hwid":"D03E7AAF8DFE6E4637EA4CA88C1D2D24763AAD5A6715D1E6F48F00C74D0BCD94","notes":"Generated from Tool","used":false,"userName":"عبدالرحيم عبادي"},
  "7744077440":{"createdAt":"2025-12-29T05:24:24.474Z","expiresAt":"2026-12-29","hwid":"","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"عبدالرحمن الدياب"},
  "8132836035":{"createdAt":"2025-12-06T12:00:34.291Z","expiresAt":"2026-12-06","hwid":"5E039AAFBDE1FA585ED3C8A4DFAA2669276D511E8C48EEA165A6E751F24772DC","notes":"تم الإنشاء عبر تطبيق الويب","used":false,"userName":"Ivan Adi Chandra"},
  "ammar0099":{"createdAt":"2025-12-02T05:06:13Z","expiresAt":"2026/12/02","hwid":"CD4310CAC0B5116EC6A9C30DB20848A5E0A82E25440BAC690DC41119D4D61DAA","notes":"Generated from Tool","used":false,"userName":"كنان"}
};

function parseExpiresAt(expiresAt: string): Date {
  // Handle different date formats
  const cleaned = expiresAt.replace(/\//g, '-');
  const date = new Date(cleaned);
  if (isNaN(date.getTime())) {
    // Default to 1 year from now if parsing fails
    return new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
  }
  return date;
}

function calculateDurationDays(createdAt: string | undefined, expiresAt: string): number {
  const created = createdAt ? new Date(createdAt) : new Date();
  const expires = parseExpiresAt(expiresAt);
  const diffMs = expires.getTime() - created.getTime();
  return Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get admin user id (ampro)
    const { data: adminUser } = await supabaseClient.auth.admin.listUsers();
    const admin = adminUser?.users?.find(u => u.email === 'ampro@admin.com');
    
    if (!admin) {
      return new Response(
        JSON.stringify({ error: "Admin user not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const results = {
      success: 0,
      failed: 0,
      skipped: 0,
      errors: [] as string[]
    };

    for (const [key, license] of Object.entries(firebaseLicenses)) {
      try {
        // Check if license already exists
        const { data: existing } = await supabaseClient
          .from('licenses')
          .select('id')
          .eq('license_key', key)
          .maybeSingle();

        if (existing) {
          results.skipped++;
          continue;
        }

        const licenseData = license as any;
        const expiresAt = parseExpiresAt(licenseData.expiresAt);
        const durationDays = calculateDurationDays(licenseData.createdAt, licenseData.expiresAt);
        const createdAt = licenseData.createdAt ? new Date(licenseData.createdAt) : new Date();
        
        // Handle invalid createdAt dates
        const validCreatedAt = isNaN(createdAt.getTime()) ? new Date() : createdAt;

        const { error } = await supabaseClient
          .from('licenses')
          .insert({
            license_key: key,
            customer_name: licenseData.userName,
            tool_type: 'AMPro Tool',
            device_serial: licenseData.hwid || null,
            expires_at: expiresAt.toISOString(),
            duration_days: durationDays,
            is_active: !licenseData.used && expiresAt > new Date(),
            created_by: admin.id,
            created_at: validCreatedAt.toISOString(),
            updated_at: new Date().toISOString()
          });

        if (error) {
          results.failed++;
          results.errors.push(`${key}: ${error.message}`);
        } else {
          results.success++;
        }
      } catch (err: any) {
        results.failed++;
        results.errors.push(`${key}: ${err?.message || 'Unknown error'}`);
      }
    }

    return new Response(
      JSON.stringify({
        message: "Migration completed",
        results
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: error?.message || 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
