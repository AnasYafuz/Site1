import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SetupRequest {
  adminEmail: string
  adminPassword: string
  adminName: string
  managerEmail?: string
  managerPassword?: string
  managerName?: string
  managerMaxLicenses?: number
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })

    const { 
      adminEmail, 
      adminPassword, 
      adminName,
      managerEmail,
      managerPassword,
      managerName,
      managerMaxLicenses = 10
    }: SetupRequest = await req.json()

    console.log('Setting up initial users...')

    // Create admin user
    const { data: adminData, error: adminError } = await supabase.auth.admin.createUser({
      email: adminEmail,
      password: adminPassword,
      email_confirm: true,
      user_metadata: { name: adminName },
    })

    if (adminError) {
      console.error('Error creating admin:', adminError)
      return new Response(
        JSON.stringify({ error: `Failed to create admin: ${adminError.message}` }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Admin created:', adminData.user.id)

    // Update admin profile
    await supabase.from('profiles').update({ name: adminName }).eq('id', adminData.user.id)

    // Add admin role
    const { error: adminRoleError } = await supabase.from('user_roles').insert({
      user_id: adminData.user.id,
      role: 'admin',
    })

    if (adminRoleError) {
      console.error('Error adding admin role:', adminRoleError)
    }

    let managerData = null

    // Create manager if provided
    if (managerEmail && managerPassword && managerName) {
      const { data: mgrData, error: mgrError } = await supabase.auth.admin.createUser({
        email: managerEmail,
        password: managerPassword,
        email_confirm: true,
        user_metadata: { name: managerName },
      })

      if (mgrError) {
        console.error('Error creating manager:', mgrError)
      } else {
        managerData = mgrData
        console.log('Manager created:', mgrData.user.id)

        // Update manager profile
        await supabase.from('profiles').update({ 
          name: managerName,
          max_licenses: managerMaxLicenses,
        }).eq('id', mgrData.user.id)

        // Add manager role
        await supabase.from('user_roles').insert({
          user_id: mgrData.user.id,
          role: 'manager',
        })
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Users created successfully',
        admin: { id: adminData.user.id, email: adminEmail },
        manager: managerData ? { id: managerData.user.id, email: managerEmail } : null,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error: unknown) {
    console.error('Error in setup-users:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
