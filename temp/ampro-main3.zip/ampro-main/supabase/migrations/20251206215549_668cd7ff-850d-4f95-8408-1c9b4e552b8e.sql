-- Create a table to track online devices
CREATE TABLE public.online_devices (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    device_name TEXT NOT NULL,
    user_type TEXT NOT NULL DEFAULT 'admin',
    last_seen TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    is_online BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.online_devices ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read devices (for admin dashboard)
CREATE POLICY "Anyone can view online devices" 
ON public.online_devices 
FOR SELECT 
USING (true);

-- Allow anyone to insert their device
CREATE POLICY "Anyone can register their device" 
ON public.online_devices 
FOR INSERT 
WITH CHECK (true);

-- Allow anyone to update their device status
CREATE POLICY "Anyone can update device status" 
ON public.online_devices 
FOR UPDATE 
USING (true);

-- Allow anyone to delete their device
CREATE POLICY "Anyone can delete their device" 
ON public.online_devices 
FOR DELETE 
USING (true);

-- Enable realtime for this table
ALTER PUBLICATION supabase_realtime ADD TABLE public.online_devices;