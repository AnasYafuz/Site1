-- Create table for banned devices
CREATE TABLE public.banned_devices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  device_name TEXT NOT NULL,
  banned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  banned_until TIMESTAMP WITH TIME ZONE NOT NULL,
  banned_by TEXT NOT NULL DEFAULT 'admin'::text,
  reason TEXT
);

-- Enable RLS
ALTER TABLE public.banned_devices ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view banned devices" 
ON public.banned_devices 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can ban devices" 
ON public.banned_devices 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can delete banned devices" 
ON public.banned_devices 
FOR DELETE 
USING (true);