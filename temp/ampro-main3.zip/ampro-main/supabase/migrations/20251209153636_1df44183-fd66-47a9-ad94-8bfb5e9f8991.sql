-- Create activity_logs table
CREATE TABLE public.activity_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  action_type TEXT NOT NULL,
  license_key TEXT,
  user_name TEXT,
  performed_by TEXT NOT NULL DEFAULT 'admin',
  details TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view activity logs" 
ON public.activity_logs 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can insert activity logs" 
ON public.activity_logs 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Anyone can delete activity logs" 
ON public.activity_logs 
FOR DELETE 
USING (true);