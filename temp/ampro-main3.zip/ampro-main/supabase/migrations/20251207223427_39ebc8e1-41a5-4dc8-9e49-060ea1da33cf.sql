-- Create deleted_licenses table to store deleted licenses history
CREATE TABLE public.deleted_licenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  original_key TEXT NOT NULL,
  user_name TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  hwid TEXT,
  notes TEXT,
  deleted_by TEXT NOT NULL DEFAULT 'admin',
  deleted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.deleted_licenses ENABLE ROW LEVEL SECURITY;

-- Allow anyone to view deleted licenses
CREATE POLICY "Anyone can view deleted licenses"
ON public.deleted_licenses
FOR SELECT
USING (true);

-- Allow anyone to insert deleted licenses
CREATE POLICY "Anyone can insert deleted licenses"
ON public.deleted_licenses
FOR INSERT
WITH CHECK (true);

-- Allow anyone to delete from deleted_licenses
CREATE POLICY "Anyone can delete from deleted_licenses"
ON public.deleted_licenses
FOR DELETE
USING (true);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.deleted_licenses;